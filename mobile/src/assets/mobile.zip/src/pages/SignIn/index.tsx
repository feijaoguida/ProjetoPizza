import React from 'react';
import { View, Text } from 'react-native'

export default function SignIn(){
  return(
    <View>
      <Text>Tela de login</Text>
    </View>
  )
}